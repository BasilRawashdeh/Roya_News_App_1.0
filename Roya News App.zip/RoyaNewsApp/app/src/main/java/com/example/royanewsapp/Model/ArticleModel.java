package com.example.royanewsapp.Model;

import android.media.Image;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class ArticleModel {
    @PrimaryKey
    public int newsID;

    @ColumnInfo(name = "news_image")
    public String newsImage;

    @ColumnInfo(name = "news_title")
    public String newsTitle;

    @ColumnInfo(name = "news_section_name")
    public String newsSectionName;

}
